import tkinter as tk
from model.analizador import AnalizadorLL1
from view.gui import VistaAnalizador
from controller.controlador import ControladorAnalizador

class Aplicacion:
    """Clase principal que inicia la aplicación"""
    
    def __init__(self):
        self.root = tk.Tk()
        self.modelo = AnalizadorLL1()
        self.vista = VistaAnalizador(self.root)
        self.controlador = ControladorAnalizador(self.vista, self.modelo)
        
        self._configurar_ventana()
        
    def _configurar_ventana(self):
        """Configura propiedades de la ventana principal"""
        self.root.title("Analizador Sintáctico LL(1) - Compiladores")
        self.root.geometry("800x750")
        self.root.minsize(700, 650)
        
    def ejecutar(self):
        """Inicia la aplicación"""
        self.root.mainloop()

if __name__ == "__main__":
    app = Aplicacion()
    app.ejecutar()