class AnalizadorLL1:
    """Implementa el modelo del analizador sintáctico LL(1) con tabla predefinida"""
    
    def __init__(self):
        # Tabla de análisis LL(1) predefinida según la gramática
        self.tabla = {
            'E': {'id': ['T', "E'"], '(': ['T', "E'"]},
            "E'": {'+': ['+', 'T', "E'"], ')': ['ε'], '$': ['ε']},
            'T': {'id': ['F', "T'"], '(': ['F', "T'"]},
            "T'": {'+': ['ε'], '*': ['*', 'F', "T'"], ')': ['ε'], '$': ['ε']},
            'F': {'id': ['id'], '(': ['(', 'E', ')']}
        }
        self.registro = []
        self.gramatica = """
        Gramática LL(1) para expresiones aritméticas:
        E → TE'
        E' → +TE' | ε
        T → FT'
        T' → *FT' | ε
        F → id | (E)
        """
        self.tokens_validos = {'id', '+', '*', '(', ')', '$'}
    
    def analizar(self, cadena):
        """Realiza el análisis sintáctico de una cadena"""
        self.registro = []
        tokens = cadena.split()
        
        # Validación de tokens
        tokens_invalidos = [t for t in tokens if t not in self.tokens_validos]
        if tokens_invalidos:
            raise ValueError(f"Tokens no válidos: {tokens_invalidos}")
        
        pila = ["$", "E"]
        entrada = tokens + ["$"]
        
        while True:
            X = pila[-1]
            a = entrada[0]
            self._registrar_paso(pila.copy(), entrada.copy(), "")
            
            # Caso 1: Aceptación
            if X == a == "$":
                self.registro[-1]["accion"] = "ACEPTAR"
                return True
                
            # Caso 2: Coincidencia de terminales
            if X == a:
                pila.pop()
                entrada.pop(0)
                self.registro[-1]["accion"] = f"Coincide: {X}"
                continue
                
            # Caso 3: Consultar tabla
            if X in self.tabla and a in self.tabla[X]:
                produccion = self.tabla[X][a]
                pila.pop()
                if produccion != ['ε']:
                    pila.extend(reversed(produccion))
                self.registro[-1]["accion"] = f"Aplica: {X} → {' '.join(produccion)}"
            else:
                # Manejo de epsilon productions
                if X in self.tabla and 'ε' in [p for prods in self.tabla[X].values() for p in prods]:
                    pila.pop()
                    self.registro[-1]["accion"] = f"Aplica: {X} → ε"
                    continue
                    
                self.registro[-1]["accion"] = f"ERROR: No hay regla para {X} con {a}"
                return False
    
    def _registrar_paso(self, pila, entrada, accion):
        """Registra un paso del análisis"""
        self.registro.append({
            "pila": " ".join(pila),
            "entrada": " ".join(entrada),
            "accion": accion
        })
    
    def obtener_registro(self):
        """Devuelve el registro de análisis"""
        return self.registro.copy()
    
    def obtener_gramatica(self):
        """Devuelve la gramática"""
        return self.gramatica
    
    def obtener_tabla_formateada(self):
        """Devuelve la tabla formateada para visualización"""
        texto = "TABLA LL(1)\n\n"
        texto += "{:<10} | {:<10} | {:<20}\n".format("NoTerminal", "Terminal", "Producción")
        texto += "-"*45 + "\n"
        
        for nt in sorted(self.tabla.keys()):
            for t in sorted(self.tabla[nt].keys()):
                prod = ' '.join(self.tabla[nt][t])
                texto += "{:<10} | {:<10} | {:<20}\n".format(nt, t, prod)
                
        return texto