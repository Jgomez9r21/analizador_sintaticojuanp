import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox

class VistaAnalizador:
    """Implementa la interfaz gráfica del analizador"""
    
    def __init__(self, root):
        self.root = root
        self.controlador = None
        self._configurar_interfaz()
    
    def _configurar_interfaz(self):
        """Configura todos los elementos de la GUI"""
        self.root.title("Analizador LL(1) - Compiladores")
        self.root.geometry("1000x700")
        
        # Frame principal con pestañas
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Pestañas
        self._crear_pestana_analisis()
        self._crear_pestana_gramatica()
        
        # Barra de estado
        self.barra_estado = ttk.Label(self.root, text="Listo", relief=tk.SUNKEN)
        self.barra_estado.pack(fill=tk.X, side=tk.BOTTOM)
    
    def _crear_pestana_analisis(self):
        """Crea la pestaña de análisis sintáctico"""
        frame = ttk.Frame(self.notebook)
        self.notebook.add(frame, text="Análisis")
        
        # Panel de entrada
        entrada_frame = ttk.LabelFrame(frame, text="Entrada", padding=10)
        entrada_frame.pack(fill=tk.X, padx=5, pady=5)
        
        ttk.Label(entrada_frame, text="Cadena a analizar:").pack(anchor=tk.W)
        
        self.entrada = ttk.Entry(entrada_frame, font=('Arial', 11))
        self.entrada.pack(fill=tk.X, pady=5)
        self.entrada.insert(0, "id + id * id")
        
        ttk.Label(entrada_frame, text="Tokens válidos: id, +, *, (, )", 
                 foreground="blue").pack(anchor=tk.W)
        
        # Panel de botones
        btn_frame = ttk.Frame(frame)
        btn_frame.pack(fill=tk.X, pady=10)
        
        ttk.Button(
            btn_frame, 
            text="Analizar Cadena", 
            command=self._analizar
        ).pack(side=tk.LEFT, padx=5)
        
        ttk.Button(
            btn_frame,
            text="Limpiar",
            command=self.limpiar_resultados
        ).pack(side=tk.RIGHT, padx=5)
        
        # Panel de resultados
        resultados_frame = ttk.LabelFrame(frame, text="Resultados del Análisis", padding=10)
        resultados_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        self.resultado_analisis = ttk.Label(
            resultados_frame, 
            text="", 
            font=('Arial', 12, 'bold'),
            foreground="green"
        )
        self.resultado_analisis.pack(anchor=tk.W, pady=5)
        
        self.tab_analisis = scrolledtext.ScrolledText(
            resultados_frame, 
            wrap=tk.WORD, 
            font=('Consolas', 10),
            padx=10,
            pady=10,
            state='normal'
        )
        self.tab_analisis.pack(fill=tk.BOTH, expand=True)
    
    def _crear_pestana_gramatica(self):
        """Crea la pestaña de gramática y tabla"""
        frame = ttk.Frame(self.notebook)
        self.notebook.add(frame, text="Gramática y Tabla")
        
        # Panel de gramática
        gramatica_frame = ttk.LabelFrame(frame, text="Gramática", padding=10)
        gramatica_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        self.tab_gramatica = scrolledtext.ScrolledText(
            gramatica_frame,
            wrap=tk.WORD,
            font=('Consolas', 10),
            padx=10,
            pady=10,
            state='normal'
        )
        self.tab_gramatica.pack(fill=tk.BOTH, expand=True)
        
        # Panel de tabla
        tabla_frame = ttk.LabelFrame(frame, text="Tabla LL(1)", padding=10)
        tabla_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        self.tab_tabla = scrolledtext.ScrolledText(
            tabla_frame,
            wrap=tk.WORD,
            font=('Consolas', 10),
            padx=10,
            pady=10,
            state='normal'
        )
        self.tab_tabla.pack(fill=tk.BOTH, expand=True)
        
        if self.controlador:
            self.mostrar_gramatica()
            self.mostrar_tabla(self.controlador._formatear_tabla())
    
    def _analizar(self):
        """Maneja el evento de análisis"""
        if self.controlador:
            cadena = self.entrada.get().strip()
            self.controlador.analizar_cadena(cadena)
    
    def set_controlador(self, controlador):
        """Establece el controlador"""
        self.controlador = controlador
        self.mostrar_gramatica()
        self.mostrar_tabla(self.controlador._formatear_tabla())
    
    def mostrar_traza(self, contenido):
        """Muestra la prueba de escritorio"""
        self.tab_analisis.config(state='normal')
        self.tab_analisis.delete(1.0, tk.END)
        self.tab_analisis.insert(tk.END, contenido)
        self.tab_analisis.config(state='disabled')
        self.notebook.select(0)
    
    def mostrar_tabla(self, contenido):
        """Muestra la tabla de análisis"""
        self.tab_tabla.config(state='normal')
        self.tab_tabla.delete(1.0, tk.END)
        self.tab_tabla.insert(tk.END, contenido)
        self.tab_tabla.config(state='disabled')
        self.notebook.select(1)
    
    def mostrar_gramatica(self, gramatica=None):
        """Muestra la gramática"""
        if not gramatica and self.controlador:
            gramatica = self.controlador.obtener_gramatica()
        
        self.tab_gramatica.config(state='normal')
        self.tab_gramatica.delete(1.0, tk.END)
        self.tab_gramatica.insert(tk.END, gramatica)
        self.tab_gramatica.config(state='disabled')
    
    def mostrar_resultado(self, mensaje):
        """Muestra el resultado del análisis"""
        color = "green" if "ACEPTADA" in mensaje else "red"
        self.resultado_analisis.config(text=mensaje, foreground=color)
    
    def mostrar_error(self, mensaje):
        """Muestra un mensaje de error"""
        self.barra_estado.config(text=f"Error: {mensaje}", foreground="red")
        messagebox.showerror("Error", mensaje)
    
    def limpiar_resultados(self):
        """Limpia los resultados del análisis"""
        self.tab_analisis.config(state='normal')
        self.tab_analisis.delete(1.0, tk.END)
        self.tab_analisis.config(state='disabled')
        self.entrada.delete(0, tk.END)
        self.entrada.insert(0, "id + id * id")
        self.resultado_analisis.config(text="")
        self.barra_estado.config(text="Listo", foreground="black")