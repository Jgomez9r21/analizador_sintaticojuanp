from tkinter import messagebox

class ControladorAnalizador:
    """Implementa el controlador del analizador LL(1)"""
    
    def __init__(self, vista, modelo):
        self.vista = vista
        self.modelo = modelo
        self.vista.set_controlador(self)
    
    def analizar_cadena(self, cadena):
        """Maneja el análisis de una cadena"""
        try:
            if not cadena.strip():
                raise ValueError("Ingrese una cadena para analizar")
                
            resultado = self.modelo.analizar(cadena)
            prueba = self._formatear_prueba()
            
            self.vista.mostrar_traza(prueba)
            
            mensaje = "✅ Cadena ACEPTADA" if resultado else "❌ Cadena RECHAZADA"
            self.vista.mostrar_resultado(mensaje)
            
        except ValueError as e:
            self.vista.mostrar_error(str(e))
        except Exception as e:
            self.vista.mostrar_error(f"Error durante el análisis: {str(e)}")
    
    def _formatear_tabla(self):
        """Devuelve la tabla formateada para visualización"""
        return self.modelo.obtener_tabla_formateada()
    
    def _formatear_prueba(self):
        """Formatea la prueba de escritorio según el formato solicitado"""
        registro = self.modelo.obtener_registro()
        
        texto = "\nPRUEBA DE ESCRITORIO - ANÁLISIS LL(1)\n"
        texto += "-"*70 + "\n"
        texto += "{:<20} | {:<20} | {:<25}\n".format("PILA", "ENTRADA", "SALIDA")
        texto += "-"*70 + "\n"
        
        for paso in registro:
            accion = paso["accion"]
            
            # Formatear la salida según el ejemplo
            if "Aplica:" in accion:
                salida = accion.replace("Aplica: ", "")
            elif "Coincide:" in accion:
                salida = f"Coincide: {accion.split(': ')[1]}"
            elif "ACEPTAR" in accion:
                salida = "ACEPTAR"
            else:
                salida = accion
                
            texto += "{:<20} | {:<20} | {:<25}\n".format(
                paso["pila"], 
                paso["entrada"], 
                salida
            )
        
        texto += "-"*70 + "\n"
        return texto
    
    def obtener_gramatica(self):
        """Obtiene la gramática del modelo"""
        return self.modelo.obtener_gramatica()